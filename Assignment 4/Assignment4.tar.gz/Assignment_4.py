import numpy  as np
import matplotlib.pyplot as plt
import scipy.integrate

def exp(x):
    return np.exp(x)

def coscos(x):
    return np.cos(np.cos(x))

def plotter(fig_no,plot_x,plot_y,label_x,label_y,type=None,kind='b-',title=""):
    plt.figure(fig_no)
    plt.grid(True)
    if type =="semilogy":
        plt.semilogy(plot_x,plot_y,kind)
    elif type =='ll':
        plt.loglog(plot_x,plot_y,kind)
    elif type ==None:
        plt.plot(plot_x,plot_y,kind)
    plt.xlabel(label_x,size =19)
    plt.ylabel(label_y,size =19)
    plt.title(title)
    

def u1(x,k):
    return(coscos(x)*np.cos(k*x))

def v1(x,k):
    return(coscos(x)*np.sin(k*x))

def u2(x,k):
    return(exp(x)*np.cos(k*x))

def v2(x,k):
    return(exp(x)*np.sin(k*x))


def integrate():
    a = np.zeros(51)
    b = np.zeros(51)
    a[0] =  scipy.integrate.quad(exp,0,2*np.pi)[0]/(2*np.pi)
    b[0] =  scipy.integrate.quad(coscos,0,2*np.pi)[0]/(2*np.pi)
    for i in range(1,51,2):
        a[i] = scipy.integrate.quad(u2,0,2*np.pi,args=(i//2+1))[0]/(np.pi)
        b[i] = scipy.integrate.quad(u1,0,2*np.pi,args=(i//2+1))[0]/(np.pi)
        a[i+1] = scipy.integrate.quad(v2,0,2*np.pi,args=(i//2+1))[0]/(np.pi)
        b[i+1] = scipy.integrate.quad(v1,0,2*np.pi,args=(i//2+1))[0]/(np.pi)
    return a,b

t = np.linspace(-2*np.pi,4*np.pi,1200)
fr_length = np.arange(1,52)#Fourier Coefficient Number

plotter(1,t,exp(t),r"$t$",r"exp(t)","semilogy",title ="Exponential Function on a semilog plot")
plotter(2,t,coscos(t),r"$t$",r"cos(cos(t))",title="Cos(Cos()) Function on a linear plot")
plotter(1,t,np.concatenate((exp(t)[400:800],exp(t)[400:800],exp(t)[400:800])),r"$t$",r"exp(t)","semilogy",'r-')
plt.legend(("true","periodic extension"))
plotter(2,t,np.concatenate((coscos(t)[400:800],coscos(t)[400:800],coscos(t)[400:800])),r"$t$",r"cos(cos(t)","semilogy",'r-')
plt.legend(("true","periodic extension"))
frexp,frcos = integrate()
plotter(3,fr_length,np.absolute(frexp),"Coefficient Number","Coefficient Value","semilogy",'ro',title="Semilog Fourier Coefficients for exp(t)")
plotter(4,fr_length,np.absolute(frexp),"Coefficient Number","Coefficient Value","ll",'ro',title="Log-Log Fourier Coefficients for exp(t)")
plotter(5,fr_length,np.absolute(frcos),"Coefficient Number","Coefficient Value","semilogy",'ro',title="Semilog Fourier Coefficients for coscos(t)")
plotter(6,fr_length,np.absolute(frcos),"Coefficient Number","Coefficient Value","ll",'ro',title="Loglog Fourier Coefficients for coscos(t)")



x =np.linspace(0,2*np.pi,400,endpoint =True)
bexp = exp(x)
bcoscos =coscos(x)
A = np.zeros((400,51))
A[:,0] =1
for k in range(1,26):
    A[:,2*k-1] = np.cos(k*x)
    A[:,2*k] = np.sin(k*x)
cexp = np.linalg.lstsq(A,bexp)[0]
ccoscos = np.linalg.lstsq(A,bcoscos)[0]
print(len(cexp),len(ccoscos),len(frexp),len(frcos),"\n\n\n\n\n\n")
plotter(3,fr_length,np.abs(cexp),"Coefficient Number","Coefficient Value","semilogy",'go',title="Semilog Fourier Coefficients for exp(t)")
plt.legend(("true","predicted"))
plotter(4,fr_length,np.abs(cexp),"Coefficient Number","Coefficient Value","ll",'go',title="Loglog Fourier Coefficients for exp(t)")
plt.legend(("true","predicted"))
plotter(5,fr_length,np.abs(ccoscos),"Coefficient Number","Coefficient Value","semilogy",'go',title="Semilog Fourier Coefficients for coscos(t)")
plt.legend(("true","predicted"))
plotter(6,fr_length,np.abs(ccoscos),"Coefficient Number","Coefficient Value","ll",'go',title="Loglog Fourier Coefficients for coscos(t)")
plt.legend(("true","predicted"))
diffexp = np.absolute(cexp-frexp)
diffcos = np.absolute(ccoscos-frcos)
print(np.amax(diffexp),np.amax(diffcos),diffexp,diffcos)

Acexp = A@cexp
Accos = A@ccoscos


plotter(1,t,np.concatenate((np.zeros(400),Acexp,np.zeros(400))),r"$t$",r"exp(t)","semilogy",'go')
plt.legend(("true","periodic extension","predicted"))
plotter(2,t,np.concatenate((np.zeros(400),Accos,np.zeros(400))),r"$t$",r"coscos(t)",None,'go')
plt.legend(("true","periodic extension","predicted"))

plt.show()
